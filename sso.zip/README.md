https://docs.oasis-open.org/security/saml/v2.0/
https://github.com/tngan/samlify/tree/f2b6a2f8c36dc0ff887d0442c48cd0f2c0a4a778/examples/idp
